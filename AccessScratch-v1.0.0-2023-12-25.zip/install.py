import sys
import datetime
import os
import time
dt = datetime.datetime.now()
print('access scratch')
print('-----------------------------------------')
print(dt, ' セットアップしています...')
time.sleep(2)
os.system("pip install -U scratchattach")
print('インストールが終わったので main.pyを起動してください')