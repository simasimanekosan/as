import scratchattch
import sys
print('access scratch v1.0.0')
print('-----------------------------------------')
print('ようこそ！いろいろするためにまずスクラッチのアカウントにログインしましょう！')
un = input('ユーザーネームを入れてください。:')
ps = input('パスワードを入れてください。:')
session = scratch3.login(un, ps)
print('ログインしました。')
while True:
	oer = input('[c]クラウド変数を操作 [s]scratchattchのコマンドを入力 [e]終了する:')
	if oer == "c"
		d = input('プロジェクトidを入れてください:')
		conn = session.connect_cloud(d)
		e = input('クラウド変数の名前を入れてください')
		f = input('変更する数字を入れてください')
		conn.set_var(e, f)
		print('設定しました。')
	elif oer == "e"
		sys.exit()